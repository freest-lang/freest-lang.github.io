```
  ______              _____ _______ 
 |  ____|            / ____|__   __|
 | |__ _ __ ___  ___| (___    | |
 |  __| '__/ _ \/ _ \___ \   | |
 | |  | | |  __/  __/____) |  | |
 |_|  |_|  \___|\___|_____/   |_|
```

# Install stack
- For Un*x-like operating systems:
```
    $ curl -sSL https://get.haskellstack.org/ | sh
```

- For windows download the installer available at: 
  
  [Get stack for windows](https://get.haskellstack.org/stable/windows-x86_64-installer.exe)

For more information about stack please visit [https://docs.haskellstack.org/en/stable/README/](https://docs.haskellstack.org/en/stable/README/)

# Install FreeST

- Extract the zip FreeST-3.1.0.zip

```
$ cd freest-3.1.0/
```

- Install FreeST
```
$ stack install FreeST
```

- Install REPL (freesti)
```
$ stack install REPL
```

- Install both
```
$ stack install
```

If you get the following warning:
```
Warning: Installation path /home/.../.local/bin
         not found on the PATH environment variable.
```

add this path to your PATH environment variable: 
```
export PATH=/home/.../.local/bin/:$PATH
```

this will only work for the current terminal session. If you want to keep it among sessions, add the previous line to your ~/.bashrc file.


# Run FreeST (program LazyTreeTraversal.fst)
```
freest examples/LazyTreeTraversal.fst
```

# Website, tutorial and some examples

- FreeST website: https://freest-lang.github.io/getting%20started/functional-freest/

- You can find a browser interpreter at [RSS Tryit](http://rss.di.fc.ul.pt/tryit/FreeST).
The examples are also available on freest-3.1.0/examples/

# FreeST modes
The language modes are available in https://freest-lang.github.io/downloads/

## License
FreeST is under the [BSD3 license.](https://opensource.org/licenses/BSD-3-Clause)


